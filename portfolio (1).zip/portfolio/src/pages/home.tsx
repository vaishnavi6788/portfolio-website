import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Resume from "@/components/Resume";
import Projects from "@/components/Projects";
import LinkedInCTA from "@/components/LinkedInCTA";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main className="min-h-screen bg-background text-foreground flex flex-col items-center selection:bg-accent selection:text-accent-foreground">
      <Navbar />
      <Hero />
      <div className="w-full max-w-4xl px-6 md:px-12 pb-24 flex flex-col gap-32">
        <Resume />
        <Projects />
        <LinkedInCTA />
        <Contact />
      </div>
      <Footer />
    </main>
  );
}
