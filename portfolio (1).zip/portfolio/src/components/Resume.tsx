import { motion } from "framer-motion";

export default function Resume() {
  const experiences = [
    {
      company: "SRDT",
      role: "Summer Training Intern",
      period: "Sep 2025",
      description:
        "Learned Python fundamentals and worked with libraries using Google Colab. Gained hands-on experience with GitHub for version control and collaboration. Developed and deployed web applications using Flask."
    },
    {
      company: "IBM",
      role: "Training & Internship",
      period: "2024",
      description:
        "Completed IBM-guided training program covering practical applications of AI and data science tools, reinforcing foundational knowledge in machine learning workflows and industry best practices."
    }
  ];

  const education = [
    {
      institution: "Shri Ramswaroop Memorial College of Engineering and Management",
      degree: "B.Tech in Computer Science — AI/ML Specialization",
      period: "2023 — 2027"
    }
  ];

  const skillGroups = [
    {
      label: "Languages",
      skills: ["Python", "SQL", "C", "Java (basic)"]
    },
    {
      label: "ML & Frameworks",
      skills: ["Scikit-learn", "TensorFlow", "PyTorch"]
    },
    {
      label: "Data Analysis",
      skills: ["Pandas", "NumPy", "Matplotlib", "Seaborn"]
    },
    {
      label: "Tools & Platforms",
      skills: ["Jupyter Notebook", "Google Colab", "Git", "VS Code", "Flask"]
    },
    {
      label: "Core Concepts",
      skills: ["Machine Learning", "Data Structures", "OOPs", "DBMS"]
    }
  ];

  const certifications = [
    { name: "Machine Learning", issuer: "Kaggle" },
    { name: "Python Programming", issuer: "Kaggle" }
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] } }
  };

  return (
    <section id="resume" className="w-full">
      <motion.div
        variants={container}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, margin: "-100px" }}
        className="space-y-16"
      >
        <div>
          <motion.h3 variants={item} className="text-xl font-serif text-primary mb-8 pb-4 border-b border-border">
            Profile
          </motion.h3>
          <motion.p variants={item} className="text-muted-foreground leading-relaxed max-w-2xl">
            Results-driven AI/ML enthusiast with a solid foundation in machine learning, data analysis, and
            Python programming. Experienced in building and deploying models using TensorFlow and
            scikit-learn. Passionate about solving real-world problems through data-driven solutions and
            continuously learning emerging AI technologies.
          </motion.p>
        </div>

        <div>
          <motion.h3 variants={item} className="text-xl font-serif text-primary mb-8 pb-4 border-b border-border">
            Experience
          </motion.h3>
          <div className="space-y-12">
            {experiences.map((exp, i) => (
              <motion.div variants={item} key={i} className="group flex flex-col md:flex-row md:gap-8">
                <div className="md:w-1/4 shrink-0 text-sm text-muted-foreground font-medium pt-1">
                  {exp.period}
                </div>
                <div className="md:w-3/4 space-y-2">
                  <h4 className="text-lg font-medium text-primary">{exp.role}</h4>
                  <div className="text-muted-foreground font-serif italic">{exp.company}</div>
                  <p className="text-muted-foreground leading-relaxed pt-2">{exp.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <div>
          <motion.h3 variants={item} className="text-xl font-serif text-primary mb-8 pb-4 border-b border-border">
            Education
          </motion.h3>
          <div className="space-y-8">
            {education.map((edu, i) => (
              <motion.div variants={item} key={i} className="flex flex-col md:flex-row md:gap-8">
                <div className="md:w-1/4 shrink-0 text-sm text-muted-foreground font-medium pt-1">
                  {edu.period}
                </div>
                <div className="md:w-3/4 space-y-1">
                  <h4 className="text-lg font-medium text-primary">{edu.degree}</h4>
                  <div className="text-muted-foreground font-serif italic">{edu.institution}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <div>
          <motion.h3 variants={item} className="text-xl font-serif text-primary mb-8 pb-4 border-b border-border">
            Skills
          </motion.h3>
          <motion.div variants={item} className="space-y-5">
            {skillGroups.map((group, i) => (
              <div key={i} className="flex flex-col md:flex-row md:gap-8">
                <div className="md:w-1/4 shrink-0 text-sm text-muted-foreground font-medium pt-1">
                  {group.label}
                </div>
                <div className="md:w-3/4 flex flex-wrap gap-2 pt-1">
                  {group.skills.map((skill, j) => (
                    <span key={j} className="px-3 py-1 bg-muted text-primary text-sm rounded-full border border-border/50">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </motion.div>
        </div>

        <div>
          <motion.h3 variants={item} className="text-xl font-serif text-primary mb-8 pb-4 border-b border-border">
            Certifications
          </motion.h3>
          <div className="space-y-4">
            {certifications.map((cert, i) => (
              <motion.div variants={item} key={i} className="flex flex-col md:flex-row md:gap-8">
                <div className="md:w-1/4 shrink-0 text-sm text-muted-foreground font-medium pt-1">
                  {cert.issuer}
                </div>
                <div className="md:w-3/4">
                  <h4 className="text-base font-medium text-primary">{cert.name}</h4>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </section>
  );
}
