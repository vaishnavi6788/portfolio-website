import { motion } from "framer-motion";
import { Download } from "lucide-react";

export default function Hero() {
  return (
    <section className="w-full max-w-4xl px-6 md:px-12 pt-32 pb-24 md:pt-48 md:pb-32 flex flex-col justify-center min-h-[70vh]">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
        className="space-y-6"
      >
        <p className="text-muted-foreground uppercase tracking-widest text-sm font-medium">Portfolio</p>
        <h1 className="text-5xl md:text-7xl font-serif text-primary leading-[1.1]">
          Vaishnavi
        </h1>
        <h2 className="text-2xl md:text-3xl text-muted-foreground font-light max-w-2xl">
          Aspiring Data Analyst. Results-driven AI/ML enthusiast building intelligent solutions through data.
        </h2>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="pt-2"
        >
          <a
            href="/resume.pdf"
            download="Vaishnavi_Resume.pdf"
            data-testid="button-download-resume"
            className="inline-flex items-center gap-2.5 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm font-medium hover:opacity-90 active:scale-95 transition-all duration-200"
          >
            <Download className="w-4 h-4" />
            Download Resume
          </a>
        </motion.div>
      </motion.div>
    </section>
  );
}
