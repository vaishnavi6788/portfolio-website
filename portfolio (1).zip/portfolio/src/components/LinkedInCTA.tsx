import { motion } from "framer-motion";
import { FaLinkedin } from "react-icons/fa";

export default function LinkedInCTA() {
  return (
    <section id="connect" className="w-full py-12">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
        viewport={{ once: true }}
        className="w-full bg-[#0A66C2]/5 border border-[#0A66C2]/20 rounded-2xl p-8 md:p-12 flex flex-col items-center text-center space-y-6 relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-[#0A66C2]/10 to-transparent opacity-50" />
        
        <div className="relative z-10 space-y-6 flex flex-col items-center">
          <FaLinkedin className="text-5xl text-[#0A66C2]" />
          <div className="space-y-2 max-w-md">
            <h3 className="text-2xl font-serif text-primary">Let's connect</h3>
            <p className="text-muted-foreground">
              I'm always open to discussing new opportunities, creative projects, or simply sharing ideas.
            </p>
          </div>
          
          <a 
            href="https://www.linkedin.com/in/vaishnavi-tiwari-228973335"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 bg-[#0A66C2] text-white px-8 py-3 rounded-full font-medium hover:bg-[#084e96] transition-colors focus:ring-4 focus:ring-[#0A66C2]/20 outline-none"
          >
            View Profile
          </a>
        </div>
      </motion.div>
    </section>
  );
}
