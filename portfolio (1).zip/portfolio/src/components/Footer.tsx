export default function Footer() {
  return (
    <footer className="w-full border-t border-border/50 py-8 mt-12">
      <div className="max-w-4xl mx-auto px-6 md:px-12 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
        <p>© {new Date().getFullYear()} Vaishnavi. All rights reserved.</p>
        <p className="font-serif italic">Crafted with intention.</p>
      </div>
    </footer>
  );
}
