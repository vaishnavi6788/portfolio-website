import { motion } from "framer-motion";
import { Github, ExternalLink } from "lucide-react";

const projects = [
  {
    name: "AI-Based Poetry & Poem Generator",
    description:
      "A poem generation system using NLP and LSTM networks with mood and topic-based customization. Users can select a theme or emotional tone and receive uniquely generated poetry. Deployed as a Flask web application with an HTML/CSS frontend.",
    stack: ["Python", "NLP", "LSTM", "TensorFlow", "Flask", "HTML/CSS"],
    github: "https://github.com/yourusername/poetry-generator",
    demo: ""
  },
  {
    name: "Rule-Based Chatbot",
    description:
      "A conversational chatbot built with Python and natural language processing techniques. Handles structured user queries through rule-based pattern matching, demonstrating core NLP concepts like tokenization and intent recognition.",
    stack: ["Python", "NLP", "NLTK"],
    github: "https://github.com/yourusername/chatbot",
    demo: ""
  }
];

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.15 }
  }
};

const item = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] } }
};

export default function Projects() {
  return (
    <section id="projects" className="w-full">
      <motion.div
        variants={container}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, margin: "-80px" }}
        className="space-y-10"
      >
        <motion.h3
          variants={item}
          className="text-xl font-serif text-primary pb-4 border-b border-border"
        >
          Projects
        </motion.h3>

        <div className="grid gap-6 md:grid-cols-2">
          {projects.map((project, i) => (
            <motion.div
              variants={item}
              key={i}
              data-testid={`card-project-${i}`}
              className="group relative flex flex-col justify-between rounded-2xl border border-border bg-muted/30 p-7 hover:border-primary/40 hover:bg-muted/60 transition-all duration-300"
            >
              <div className="space-y-4">
                <h4 className="text-lg font-medium text-primary leading-snug">
                  {project.name}
                </h4>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2 pt-1">
                  {project.stack.map((tag, j) => (
                    <span
                      key={j}
                      className="px-2.5 py-0.5 text-xs rounded-full bg-background border border-border text-muted-foreground"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-4 pt-6">
                <a
                  href={project.github}
                  target="_blank"
                  rel="noopener noreferrer"
                  data-testid={`link-github-${i}`}
                  className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  <Github className="w-4 h-4" />
                  GitHub
                </a>
                {project.demo && (
                  <a
                    href={project.demo}
                    target="_blank"
                    rel="noopener noreferrer"
                    data-testid={`link-demo-${i}`}
                    className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Live Demo
                  </a>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  );
}
