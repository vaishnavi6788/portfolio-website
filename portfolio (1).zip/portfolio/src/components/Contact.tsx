import { motion } from "framer-motion";
import { Mail, Phone, ArrowRight } from "lucide-react";

export default function Contact() {
  return (
    <section id="contact" className="w-full">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
        viewport={{ once: true }}
        className="border-t border-border pt-16 space-y-10"
      >
        <div className="space-y-3">
          <h2 className="text-3xl font-serif text-primary">Get in touch</h2>
          <p className="text-muted-foreground max-w-md">
            Open to internship opportunities, collaborative projects, and conversations about AI/ML.
          </p>
        </div>

        <div className="flex flex-col gap-5">
          <a
            href="mailto:vaishnavitiwari7806@gmail.com"
            data-testid="link-email"
            className="group inline-flex items-center gap-4 text-xl md:text-2xl font-serif text-primary hover:text-accent transition-colors"
          >
            <Mail className="w-6 h-6 text-muted-foreground group-hover:text-accent transition-colors shrink-0" />
            vaishnavitiwari7806@gmail.com
            <ArrowRight className="w-5 h-5 opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all duration-300" />
          </a>

          <a
            href="tel:7307502817"
            data-testid="link-phone"
            className="group inline-flex items-center gap-4 text-xl md:text-2xl font-serif text-primary hover:text-accent transition-colors"
          >
            <Phone className="w-6 h-6 text-muted-foreground group-hover:text-accent transition-colors shrink-0" />
            +91 7307502817
            <ArrowRight className="w-5 h-5 opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all duration-300" />
          </a>
        </div>
      </motion.div>
    </section>
  );
}
